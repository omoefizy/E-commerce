<?php
$connection = mysqli_connect('localhost', 'root', '', 'checkpoint') or die(mysqli_error());
?>