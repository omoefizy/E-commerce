<?php                   
                    echo '              
                                        <ul class="nav navbar-nav">
							<li class="active"><a href="index.php">Home</a></li>
							<li><a href="product.php" class="hvr-bounce-to-bottom">Products</a></li>
							<li><a href="about.php" class="hvr-bounce-to-bottom">About US</a></li>
							<li><a href="./contact/contact.php" class="hvr-bounce-to-bottom">Contact Us</a></li>
						</ul>';
			?>