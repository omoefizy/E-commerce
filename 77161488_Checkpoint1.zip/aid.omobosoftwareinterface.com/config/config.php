<?php
$config['base_url']='http://osi.omobosoftwareinterface.com/';
//Database
$db['hostname'] = 'localhost';
$db['port'] = 3306;
$db['username'] = 'ebiomo7-aida';
$db['password'] = 'LOVEebi@1';
$db['database'] = 'ebiomo7_aida';

?>