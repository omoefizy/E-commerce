<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8 ");

$conn = new mysqli("localhost", "ebiomo7_aida", "LOVEebi@1", "ebiomo7_aida");

$result = $conn->query("SELECT productID, name, price, quantity FROM products");

$outp ="";
while($rs = $result->fetch_array()){
	if  ($outp != ""){$outp .= ",";}
	$outp .= '{"productID":"'  . $rs["productID"] . '",';
	$outp .= '"name":"'  .$rs["name"] . '",';
	$outp .= '"price":"'  . $rs["price"] .'",';
	$outp .= '"quantity":"'  . $rs["quantity"] .'"}';
}

$outp = '{"records": ['.$outp.']}';
$conn->close();

echo($outp);
?>