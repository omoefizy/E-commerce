<?php
//Replace XXX with your twitter application variables.
define('CONSUMER_KEY', 'yuGXi8YHyQlUe3ma31FOezxmF');
define('CONSUMER_SECRET', 'IwQEVPR7RvjjYKx8gdCk4gT9eskNvUqluA2sCyABUNSKuukrxu');
define('OAUTH_CALLBACK', 'http://XXX.com/process.php');
?>