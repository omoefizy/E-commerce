<?php
//header ("Content-Type:text/xml");//Tell browser to expect xml
$connection = mysqli_connect('localhost', 'ebiomo7_aida', 'LOVEebi@1', 'ebiomo7_aida') or die(mysqli_error());

//run query to select from all records from customer table
//store the result of the query in a veriable
$result=mysqli_query($connection, "SELECT productID, name, price, quantity FROM products") or die(mysqli_error());

//Top of xml file
$_xml = '<?xml version="1.0" encoding="UTF-8"?>';
$_xml.="<products>";
while ($row=mysqli_fetch_assoc($result)){
	$_xml.="<product>";
	$_xml.="<productID>".$row['productID']."</productID>";
	$_xml.="<name>".$row['name']."</name>";
	$_xml.="<price>".$row['price']."</price>";
	$_xml.="<quantity>".$row['quantity']."</quantity>";
	$_xml.="</product>";
}
$_xml.="</products>";
$xmlobj=new SimpleXMLElement($_xml);
//output the xml result into the web page
//print $xmlobj->asXML();

$xsl = new DOMDocument;
$xsl->load('ccc.xsl');

//configure the transformer
$proc = new XSLTProcessor;

// Attach the xsl rules
$proc->importstylesheet($xsl);

echo $proc->transformToXML($xmlobj);
$xmlobj->asXML("qqq.xml"); //save to a file called ccc.xml
?>